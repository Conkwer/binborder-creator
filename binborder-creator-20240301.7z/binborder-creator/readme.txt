Only latin file names are supported.
Do not use UTF-8 filenames with special characters.

How to use:

1. edit default.psd template in Photoshop or whaterver
2. save as png 24-bit
3. run borderer.exe/cmd and select your file
4. a border will be created in the same folder as your png file
5. copy this bin to sd-card:\_gba\frames\default.bin for example (for use with gbarunner2 (at least).

2024.02.29 CC-BY