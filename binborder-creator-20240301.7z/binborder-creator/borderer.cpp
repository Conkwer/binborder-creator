#include <cstdlib>
#include <iostream>
#include <filesystem>

int main() {
    // Get the current directory
    std::filesystem::path currentDir = std::filesystem::current_path();

    // Get the path to the script
    std::filesystem::path scriptPath = currentDir / "borderer.cmd";

    // Check if the script exists
    if (!std::filesystem::exists(scriptPath)) {
        std::cerr << "Error: borderer.cmd not found in the current directory." << std::endl;
        return 1;
    }

    // Build the command to launch the script
    std::string command = "cmd /c \"" + scriptPath.string() + "\"";

    // Launch the script
    int result = std::system(command.c_str());
    if (result != 0) {
        std::cerr << "Error launching borderer.cmd." << std::endl;
        return 1;
    }

    return 0;
}